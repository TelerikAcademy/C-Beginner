#include <iostream>
using namespace std;

int main () {
  char name[30], fname[30];

  cin >> name >> fname;
  cout << fname << "! " << name << " " << fname << endl;
  return 0;
}
