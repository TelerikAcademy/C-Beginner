#include <iostream>
#include <cstring>
using namespace std;

int main () {

  char w1[100], w2[100];

  cin.getline(w1,99);

  cout << w1 << endl;

  strcpy(w2, "Lele male, pile sus zele");


  cout << w2 << endl;
  return 0;
}
