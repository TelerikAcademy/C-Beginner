#include <iostream>
using namespace std;

int main () {
  char n, pn, f;
  n='E';
  pn='B';
  f='V';

  cout << n << '\t' << pn << '\t' << f << '\t' << "!";
  cout << '\a'<<'\a'<<'\a'<<'\n';
  return 0;
}
