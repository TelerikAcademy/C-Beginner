#include <iostream>
using namespace std;

int main () {
  char A, a;
  cin >> A;

  a = A + ('a'-'A');

  cout << "Malkata na " << A << " e " << a;

  return 0;
}
