#include <iostream>
using namespace std;

int main () {
  long long i, j;
  cout << "Ot zori se skitame. Tumno e po pladne!   ";
  cout << "}=-<o" ;
  for (i=42; i>0; i=i-1){
    for (j=0;j<20000000;j++);
    cout<<'\b'<<'\b'<<'\b'<<'\b'<<'\b'<<'\b';
    cout << "}=-<o";
  }

  return 0;
}
